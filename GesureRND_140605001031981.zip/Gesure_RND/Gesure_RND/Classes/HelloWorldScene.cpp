#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(HelloWorld::menuCloseCallback) );
    pCloseItem->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width - 20, 20) );

    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(pCloseItem, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);

    /////////////////////////////
    // 3. add your codes below...

    // add a label shows "Hello World"
    // create and initialize a label
    CCLabelTTF* pLabel = CCLabelTTF::create("Hello World", "Thonburi", 34);

    // ask director the window size
    CCSize size = CCDirector::sharedDirector()->getWinSize();

    // position the label on the center of the screen
    pLabel->setPosition( ccp(size.width / 2, size.height - 20) );

    // add the label as a child to this layer
    this->addChild(pLabel, 1);

    // add "HelloWorld" splash screen"
    pSprite = CCSprite::create("HelloWorld.png");

    // position the sprite on the center of the screen
    pSprite->setPosition( ccp(size.width/2, size.height/2) );

    // add the sprite as a child to this layer
    this->addChild(pSprite, 0);
    
   // CCDirector::sharedDirector()->getTouchDispatcher()->addStandardDelegate(this, 0);
    this->setTouchEnabled(true);
    
    
    return true;
}
void HelloWorld::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
    CCTouch *touch = (CCTouch*) touches->anyObject();
    CCPoint location = touch->getLocationInView();
    CCPoint curPosition = CCDirector::sharedDirector()->convertToGL(location);
    curPosition=CCPointMake(curPosition.x, curPosition.y);
    
}

void HelloWorld::ccTouchesMoved(CCSet* touches, CCEvent* event)
{

    
    
    CCTouch *touch = (CCTouch*) touches->anyObject();
    CCPoint location = touch->getLocationInView();
    CCPoint curPosition = CCDirector::sharedDirector()->convertToGL(location);
    curPosition=CCPointMake(curPosition.x, curPosition.y);
    
    CCSetIterator it;
    it = touches->begin();
    
    #define CLAMP(x,y,z) MIN(MAX(x,y),z)
    
    
    pSprite->setPosition(curPosition);
    
    
    if(touches->count()==2)
    {
        
        
        
        if (pSprite->boundingBox().containsPoint(curPosition))
        {
            // get positions of touches
            CCTouch* touch1 = (CCTouch*)(*it);
            
            it ++;
            CCTouch* touch2 = (CCTouch*)(*it);
            
            CCPoint position1 = touch1->getLocationInView();
            position1 = CCDirector::sharedDirector()->convertToGL(position1);
            
            CCPoint oldPosition1 = touch1->getPreviousLocationInView();
            oldPosition1 = CCDirector::sharedDirector()->convertToGL(oldPosition1);
            
            CCPoint position2 = touch2->getLocationInView();
            position2 = CCDirector::sharedDirector()->convertToGL(position2);
            
            CCPoint oldPosition2 = touch2->getPreviousLocationInView();
            oldPosition2 = CCDirector::sharedDirector()->convertToGL(oldPosition2);
            
            // calculate scale factor
            float distance = ccpDistance(position1, position2);
            float oldDistance = ccpDistance(oldPosition1, oldPosition2);
            float factor = (distance <= 0 || oldDistance <= 0) ? 1.0f : distance / oldDistance;
            float oldScale = pSprite->getScale();
            float newScale = CLAMP(oldScale*factor, 0.30, 1.6);
            pSprite->setScale(newScale);
            
            
            // calculate translation
            
            
            CCPoint newPos1 = ccpAdd(position1, ccpMult(ccpSub(pSprite->getPosition(), oldPosition1), newScale/oldScale));
            CCPoint newPos2 = ccpAdd(position2, ccpMult(ccpSub(pSprite->getPosition(), oldPosition2), newScale/oldScale));
            
            
            pSprite->setPosition ( ccpMidpoint(newPos1, newPos2));
            
            
        }
        
        
    }
}

void HelloWorld::ccTouchesEnded(CCSet* touches, CCEvent* event)
{
    CCTouch *touch = (CCTouch*) touches->anyObject();
    CCPoint location = touch->getLocationInView();
    CCPoint curPosition = CCDirector::sharedDirector()->convertToGL(location);
    curPosition=CCPointMake(curPosition.x, curPosition.y);

}

void HelloWorld::menuCloseCallback(CCObject* pSender)
{
    CCDirector::sharedDirector()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
